touch tests//.timeout
CMD="valgrind --leak-check=full /home/ulises/Documents/mp/UGRMPBase-ulises/CodeProjects/miFraud3/build/Fraud3  -K 5 ../Datasets/princeton_training.dts 1> tests//.out10 2>&1"
eval $CMD
rm tests//.timeout
