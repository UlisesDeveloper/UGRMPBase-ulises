/*
 * Metodología de la Programación
 * Curso 2025/2026
 */

/**
 * @file main.cpp
 * @author estudiante1: Romero López, Ulises
 * @author estudiante2: Ruiz Cano, Juan
 */

#include <iostream>
#include <string>
#include <sstream>
#include <regex>
#include <cmath>
#include <vector>
#include <functional>
#include <fstream>
#include <iomanip>

#define private public
#include "DataSet.h"
#include "Clustering.h"
#undef private

using namespace std;

/**
 * Shows help about the use of this program in the given output stream
 * @param outputStream The output stream where the help will be shown (for example,
 * cout, cerr, etc)
 * @param message Additional message to show with the help
 */
void showHelp(std::ostream& outputStream, const string &message) {
    outputStream << "ERROR in Fraud3 parameters. " << message << endl;
    outputStream << "Run with the following arguments:" << endl;
    outputStream << "Fraud3 [-K <K>] [-o <outputFile.dts>] <inputFile.dts>" << 
        endl;
    outputStream << endl;
    outputStream << "Parameters:" << endl;
    outputStream << "-K <K>: an integer with the number of clusters to use " << 
        "(5 by default)" << endl;
    outputStream << "-o <outputFile.dts>: name of the output dataset file " << 
        "(tests/output/output.dts by default)" << endl;
    outputStream << "<inputFile.dts>: name of the input dataset file" << endl;
    outputStream << endl;
}





/*
//only for unit tests

// Inclusión de ficheros .h que deben eliminarse tras comprobar los tests de unidad
#include <sstream>
#include <regex>
#include <cmath>
#include <string>

// Macros que deben eliminarse tras comprobar los tests de unidad
#define ENDL "\n"
#define LOCATION_DEFAULT "0.000000 0.000000"
#define LOCATION_OTHER "37.200000 -3.600000 Granada"
#define VECTOR_527 "5 7 7 7 7 7 "
#define VECTOR_DEFAULT5 "5 0 0 0 0 0 "

// Función auxiliar que usa algún test
void fill_vlocation(VectorLocation & locs, int size){
    Location loc;
    for (int i=0; i < size; i++) {
        loc.set(i,i,string("Location"+std::to_string(i)));
        locs.append(loc);
    }
}

// Función auxiliar que usa algún test
void refill_vlocation(VectorLocation &locs, int size){
    fill_vlocation(locs, size);
}
*/










/**
 * The purpose of this program is to read a dataset from a dts file, to reduce 
 * its dimensionality using clustering, and to save the resulting dataset in 
 * another dts file.
 * 
 * The number of clusters K to be used in the clustering process can be provided
 * as an optional argument (if not provided, K=5 is used). 
 * The name of the output dts file can be provided to the program as an optional
 * argument (if not provided, the output file is tests/output/output.dts). 
 * The name of the input dts file is passed as the last argument to the program.
 * See below the Running sintax.
 * 
 * The program begins by processing the command line arguments. Then, it loads 
 * the input dataset from the given dts file. After that, it performs a  
 * clustering of the locations in the dataset using the K-means algorithm with
 * the provided K value. Then, using the calculated clustering, it obtains a new 
 * dataset with reduced dimensionality. Finally, it saves the resulting dataset 
 * in the given output dts file.
 * 
 * Running sintax:
 * > build/Fraud3 [-K <K>] [-o <outputFile.dts>] <inputFile.dts>  
 * 
 * Running example:
 * > build/Fraud3 -K 5 -o /tmp/princeton_training_reduced.dts ../Datasets/princeton_training.dts
 */
int main(int argc, char* argv[]) {
    
    
    DataSet inputDataset, // Input dataset
        outputDataset; // Output dataset with reduced dimensionality

    // Name of the output file (tests/output/output.dts by default)
    string outputFileName="tests/output/output.dts";
    int K = 5; // Number of clusters (5 by default)
    Clustering clustering; // Clustering object

    // Indicates if all the parameters starting with - has been read
    bool hasBeenReadInitialParameters = false; 
    int indexInputFile = -1; // index of the input file in argv

    // Loop to process program arguments
    
    for (int i = 1; i < argc; ++i) {
        string arg = argv[i];
        if (arg == "-K") {
            if (i + 1 < argc) { 
                K = atoi(argv[++i]); 
            } else {
                showHelp(cerr, "Number of clusters not provided after -K");
                return 1;
            }
        } else if (arg == "-o") {
            if (i + 1 < argc) { 
                outputFileName = argv[++i];
            } else {
                showHelp(cerr, "Missing value for -o");
                return 1;
            }
        } else {
            // If it doesn't match a flag, it must be the input file
            indexInputFile = i;
        }
    }

    if (indexInputFile == -1) {
        showHelp(cerr, "Input file not provided");
        return 1;
    }

    // Load the input dataset from the given file
    inputDataset.load(argv[indexInputFile]);

    // Set the location vector and K in the clustering object. Use the default
    // seed value.
    clustering.set(inputDataset.getVectorLocation() , K); //Suppose its the the location vector inside the inputDataset
    // Run the clustering algorithm
    clustering.run();
    // Get the dataset with reduced dimensionality 
    //Suppose that i have to assign it to output dataset
    outputDataset = inputDataset.getReducedDataSet(clustering);

    // Save the output dataset in the given file
    outputDataset.save(outputFileName);
    
    return 0;

    
}


